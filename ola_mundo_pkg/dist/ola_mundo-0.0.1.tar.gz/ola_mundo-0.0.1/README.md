# ola_mundo

Description. 
O pacote traz uma saudação para te livrar da maldição.
	função: olá mundo

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install ola_mundo

```bash
pip install ola_mundo
```


## Author
José Carlos Lima

## License
[MIT](https://choosealicense.com/licenses/mit/)