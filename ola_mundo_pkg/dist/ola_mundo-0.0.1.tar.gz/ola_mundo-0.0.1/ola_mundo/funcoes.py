nome = input("Informe o seu nome: ")
print(f"Seja bem vindo ao Olá Mundo, {nome}!")